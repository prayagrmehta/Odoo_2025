from rest_framework import serializers
from .models import SwapRequest
from users.serializers import UserSerializer
from skills.serializers import SkillSerializer

class SwapRequestSerializer(serializers.ModelSerializer):
    from_user = UserSerializer(read_only=True)
    to_user = UserSerializer(read_only=True)
    skills_offered = SkillSerializer(many=True, read_only=True)
    skills_wanted = SkillSerializer(many=True, read_only=True)

    class Meta:
        model = SwapRequest
        fields = [
            'id', 'from_user', 'to_user', 'skills_offered', 'skills_wanted',
            'message', 'status', 'created_at', 'updated_at'
        ]
        read_only_fields = ['from_user', 'status', 'created_at', 'updated_at']

class SwapRequestCreateSerializer(serializers.ModelSerializer):
    skills_offered = serializers.ListField(child=serializers.IntegerField(), write_only=True)
    skills_wanted = serializers.ListField(child=serializers.IntegerField(), write_only=True)
    to_user_id = serializers.IntegerField(write_only=True)

    class Meta:
        model = SwapRequest
        fields = ['to_user_id', 'skills_offered', 'skills_wanted', 'message']

class SwapRequestUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = SwapRequest
        fields = ['status'] 