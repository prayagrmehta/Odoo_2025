from django.db import models
from users.models import User
from skills.models import Skill

class SwapRequest(models.Model):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('accepted', 'Accepted'),
        ('rejected', 'Rejected'),
    )
    
    from_user = models.ForeignKey(User, related_name='sent_swaps', on_delete=models.CASCADE)
    to_user = models.ForeignKey(User, related_name='received_swaps', on_delete=models.CASCADE)
    skills_offered = models.ManyToManyField(Skill, related_name='offered_in_swaps')
    skills_wanted = models.ManyToManyField(Skill, related_name='wanted_in_swaps')
    message = models.TextField(blank=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Swap request from {self.from_user.username} to {self.to_user.username}"

    class Meta:
        ordering = ['-created_at'] 