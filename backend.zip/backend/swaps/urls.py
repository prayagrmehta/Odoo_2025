from django.urls import path
from .views import SwapRequestListCreateView, SwapRequestUpdateView

urlpatterns = [
    path('', SwapRequestListCreateView.as_view(), name='swap-list-create'),
    path('<int:pk>/', SwapRequestUpdateView.as_view(), name='swap-update'),
] 