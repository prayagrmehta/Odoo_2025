from rest_framework import generics, permissions, status
from rest_framework.response import Response
from .models import SwapRequest
from .serializers import SwapRequestSerializer, SwapRequestCreateSerializer, SwapRequestUpdateSerializer
from skills.models import Skill
from users.models import User
from rest_framework import serializers

class SwapRequestListCreateView(generics.ListCreateAPIView):
    serializer_class = SwapRequestSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        return SwapRequest.objects.filter(from_user=user) | SwapRequest.objects.filter(to_user=user)

    def get_serializer_class(self):
        if self.request.method == 'POST':
            return SwapRequestCreateSerializer
        return SwapRequestSerializer

    def perform_create(self, serializer):
        offered_ids = self.request.data.get('skills_offered', [])
        wanted_ids = self.request.data.get('skills_wanted', [])
        to_user_id = self.request.data.get('to_user_id')
        
        try:
            to_user = User.objects.get(id=to_user_id)
        except User.DoesNotExist:
            raise serializers.ValidationError("Target user not found")
        
        swap = serializer.save(from_user=self.request.user, to_user=to_user)
        
        if offered_ids:
            swap.skills_offered.set(Skill.objects.filter(id__in=offered_ids))
        if wanted_ids:
            swap.skills_wanted.set(Skill.objects.filter(id__in=wanted_ids))

class SwapRequestUpdateView(generics.UpdateAPIView):
    queryset = SwapRequest.objects.all()
    serializer_class = SwapRequestUpdateSerializer
    permission_classes = [permissions.IsAuthenticated]
    http_method_names = ['patch']

    def patch(self, request, *args, **kwargs):
        swap = self.get_object()
        
        # Only the recipient can update the status
        if swap.to_user != request.user:
            return Response(
                {'error': 'Only the recipient can update this request'}, 
                status=status.HTTP_403_FORBIDDEN
            )
        
        status_val = request.data.get('status')
        if status_val in ['accepted', 'rejected']:
            swap.status = status_val
            swap.save()
            return Response(SwapRequestSerializer(swap).data)
        
        return Response(
            {'error': 'Invalid status. Must be "accepted" or "rejected"'}, 
            status=status.HTTP_400_BAD_REQUEST
        ) 