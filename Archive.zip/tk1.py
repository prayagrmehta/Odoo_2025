import openai
import re
import numpy as np
from difflib import SequenceMatcher

openai.api_key = "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"  

SKILL_FILE = "/Users/lakshymehta/Desktop/Hackathons/Odoo_2025_July/skills.txt"
BLOCKLIST = {
    "sex", "sexual", "nude", "naked", "porn", "pornography", "xxx", "strip", "escort", "fetish", "nsfw", "erotic",
    "hardcore", "adult", "incest", "rape", "molest", "orgy", "bang", "kamasutra", "nudity",

    "terrorist", "terrorism", "bomb", "explosive", "murder", "kill", "slaughter", "massacre", "genocide", "execute",
    "assassinate", "behead", "hang", "shoot", "stab", "decapitate", "lynch", "molotov", "torture",

    "drug", "cocaine", "heroin", "marijuana", "weed", "meth", "lsd", "ecstasy", "narcotic", "opium", "overdose",
    "addict", "dealer", "crack",

    "gun", "rifle", "pistol", "weapon", "grenade", "firearm", "sniper", "ak47", "bullet", "shooter", "ammo", "munition",

    "hack", "hacker", "phish", "phishing", "scam", "fraud", "darkweb", "ransomware", "malware", "spyware", "exploit",
    "breach", "ddos",

    "racist", "nazi", "hitler", "kkk", "homophobic", "antisemitic", "islamophobic", "slur", "bigot"
}
def load_skills(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        return sorted(set(line.strip().lower() for line in f if line.strip()))

REAL_SKILLS = load_skills(SKILL_FILE)

def is_inappropriate(text):
    try:
        res = openai.Moderation.create(input=text)
        flagged = res["results"][0]["flagged"]
        return flagged
    except Exception as e:
        print("Moderation error:", e)
        return False

def validate_with_gpt(skill, skill_list):
    prompt = f"""
You are a professional resume skill validator.

User typed: "{skill}"
Here are some known valid skills: {', '.join(skill_list[:200])}

Respond with one of the following:
- VALID: if it's a professional skill.
- SUGGESTION: <closest skill> if it's likely a typo or variant.
- INVALID: if it's gibberish or not a skill.
- INAPPROPRIATE: if the skill contains unsafe or offensive content.
"""

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt}],
            temperature=0
        )
        return response['choices'][0]['message']['content'].strip()
    except Exception as e:
        print("GPT error:", e)
        return "ERROR"

def validate_skill(skill):
    skill = skill.strip().lower()

    for bad_word in BLOCKLIST:
        if bad_word in skill:
            return False, f"Blocked for inappropriate keyword: {bad_word}"

    if is_inappropriate(skill):
        return False, "Blocked by AI: Inappropriate content."

    if skill in REAL_SKILLS:
        return True, "✅ Valid skill (exact match)."

    gpt_result = validate_with_gpt(skill, REAL_SKILLS)

    if gpt_result.startswith("VALID"):
        return True, " " + gpt_result
    elif gpt_result.startswith("SUGGESTION:"):
        return False, "Did you mean: " + gpt_result.split(":", 1)[1].strip()
    elif gpt_result.startswith("INAPPROPRIATE"):
        return False, "Rejected as inappropriate."
    else:
        return False, " " + gpt_result

if __name__ == "__main__":
    print("🔍 AI Skill Validator (type 'exit' to quit)")
    while True:
        s = input("Enter skill: ").strip()
        if s.lower() == 'exit':
            break
        valid, message = validate_skill(s)
        print(message)
